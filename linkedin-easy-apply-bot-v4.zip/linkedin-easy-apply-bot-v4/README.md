# LinkedIn Easy Apply Bot — v4

Pesquisa vagas com **Candidatura simplificada / Easy Apply**, filtra por nível, local, blacklist e score, e preenche o formulário com base em intenções. **O envio final é sempre seu**: o bot para na tela de revisão e você clica em "Enviar candidatura" se quiser.

## Instalação

Node.js 20+.

```bash
npm install
npx playwright install chromium
cp .env.example .env
```

## Uso

```bash
npm run login   # faça login no navegador que abrir e pressione ENTER no terminal
npm start
```

O login gera `linkedin-state.json` (seus cookies — não compartilhe nem suba para o Git). Se a sessão expirar, o bot avisa e você roda `npm run login` de novo.

## Fluxo

1. Busca cada termo de `JOB_QUERIES` já com o filtro Easy Apply do LinkedIn, em até `MAX_PAGES_PER_QUERY` páginas.
2. Pré-filtra pelo card (local, nível no título, blacklist) para não abrir vagas à toa.
3. Abre a vaga, lê descrição e o cabeçalho (ex.: "Remoto · Pleno-sênior") e aplica os filtros completos + score.
4. Abre o formulário, anexa o currículo se preciso, responde etapa por etapa.
5. Pergunta desconhecida e obrigatória → pergunta a você no terminal e **salva a resposta** em `data/answers.json` (ou você digita `m` e preenche no navegador). Se você só apertar ENTER, a vaga é pulada e a pergunta vai para `data/unanswered.txt`.
6. Na revisão final, pausa para você revisar e enviar manualmente. Depois fecha e descarta o rascunho se não foi enviado.
7. Tudo fica em `data/history.json`; vagas enviadas, já candidatadas ou sem Easy Apply não são reabertas.

`Ctrl+C` uma vez termina depois da vaga atual e mostra o resumo.

## Configuração (`.env`)

| Variável | Padrão | O que faz |
|---|---|---|
| `MAX_APPLICATIONS` | 20 | formulários abertos por execução |
| `MATCH_MIN_SCORE` | 65 | score mínimo (base 50, +8 termo no título, +4 na descrição) |
| `JOB_QUERIES` | — | termos de busca, separados por vírgula |
| `JOB_LOCATION` | Brasil | localização da busca |
| `MAX_PAGES_PER_QUERY` | 3 | páginas de 25 vagas por busca |
| `DATE_POSTED` | r604800 | `r86400` 24h, `r604800` 7 dias, vazio = qualquer |
| `REVIEW_BEFORE_SUBMIT` | true | pausa na revisão para você enviar |
| `INTERACTIVE_ANSWERS` | true | pergunta no terminal e aprende respostas |
| `UPLOAD_RESUME` | auto | `auto` só envia se nenhum currículo estiver selecionado; `always`; `never` |
| `DELAY_MIN_MS` / `DELAY_MAX_MS` | 1200 / 3000 | pausa aleatória entre ações |
| `ALLOWED_LEVELS`, `ALLOWED_LOCATIONS`, `EXCLUDE_UNKNOWN_LEVEL` | vazio | se preenchidos, sobrescrevem `data/filters.json` |

O currículo enviado é `curriculo.pdf` na raiz do projeto.

## Filtros

**Nível** é decidido em camadas: título → chips do LinkedIn (ex.: "Pleno-sênior") → descrição (por contagem, então "vai mentorar juniores" não derruba uma vaga sênior). Termos são comparados como palavras inteiras, então "internal" não conta como "intern". Vagas sem nível identificável são ignoradas se `excludeUnknownLevel` for `true`.

**Localização** olha só o local e o cabeçalho da vaga, não a descrição — "remote friendly" no texto não libera uma vaga presencial em São Paulo.

## Respostas (`data/answers.json`)

```json
"typescript_experience": {
  "keywords": ["typescript proficiency", "experience with typescript"],
  "answer": "Advanced"
}
```

Campos opcionais por intenção:

- `numeric`: valor usado em campos numéricos e para escolher faixas ("3-5 years", "6+"). Ex.: `years_of_experience` usa `"numeric": "3"` — **ajuste para o seu caso**.
- `clt` / `pj` / `default`: resposta escolhida pelo tipo de contratação detectado na vaga (usado em salário).
- `notIfMatches`: regex que impede o match. Ex.: o genérico de anos de experiência não responde "quantos anos com Kubernetes?" — isso vira pergunta nova para você.
- `yesNo`: força "Yes"/"No" quando as opções forem Sim/Não.

Respostas como "Advanced" ou "Strong" viram "Yes" automaticamente em perguntas Sim/Não; respostas começando com "No/Não/Nunca/0" viram "No".

## Blacklist (`data/blacklist.json`)

```json
{ "companies": ["Empresa que não quero"], "keywords": ["sales", "customer support"] }
```

## Testes

```bash
npm test          # regras de filtro, intenções, opções, score
npm run test:mock # fluxo completo do Playwright numa página que imita o Easy Apply
```

## Limitações

- O LinkedIn muda o HTML com frequência; os seletores têm alternativas, mas podem quebrar. O `test:mock` ajuda a separar "bug no bot" de "LinkedIn mudou".
- O bot não contorna CAPTCHA nem verificações de segurança; se aparecer, resolva no navegador.
- Automação viola os Termos de Uso do LinkedIn e pode levar a restrição da conta. Use ritmo baixo (`MAX_APPLICATIONS` pequeno, delays padrão).
