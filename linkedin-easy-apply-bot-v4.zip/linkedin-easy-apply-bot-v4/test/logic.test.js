import test from "node:test";
import assert from "node:assert/strict";
import { detectLevel, detectLocation, passesJobFilters, passesCardFilters } from "../src/filters.js";
import { detectIntent, answerForIntent } from "../src/storage.js";
import { chooseOption } from "../src/options.js";
import { scoreJob } from "../src/scoring.js";
import { isBlacklisted } from "../src/blacklist.js";

const filters = {
  allowedLevels: ["trainee", "pleno", "senior"],
  excludedLevels: ["junior", "jr", "estagio", "intern", "internship", "entry level"],
  allowedLocations: ["remoto", "remote", "curitiba", "sao jose dos pinhais", "pinhais"],
  excludeUnknownLevel: true
};

test("nível: título tem prioridade sobre descrição", () => {
  assert.equal(detectLevel({ title: "Senior Backend Engineer", description: "você vai mentorar devs junior" }, filters).allowed, true);
  assert.equal(detectLevel({ title: "Desenvolvedor Júnior", description: "" }, filters).allowed, false);
  assert.equal(detectLevel({ title: "Dev Pleno", description: "" }, filters).allowed, true);
  assert.equal(detectLevel({ title: "Estágio em TI" }, filters).allowed, false);
});

test("nível: 'internal'/'international' não contam como intern", () => {
  const r = detectLevel({ title: "Software Engineer", description: "internal tools for international clients. Senior level." }, filters);
  assert.equal(r.allowed, true);
});

test("nível: chip Pleno-sênior do LinkedIn", () => {
  assert.equal(detectLevel({ title: "Software Engineer", topCard: "Remoto · Tempo integral · Pleno-sênior" }, filters).allowed, true);
});

test("nível desconhecido é excluído por padrão", () => {
  assert.equal(passesJobFilters({ title: "Software Engineer", location: "Curitiba", description: "Go e AWS" }, filters).allowed, false);
});

test("localização", () => {
  assert.equal(detectLocation({ location: "Curitiba, Paraná, Brasil (Híbrido)" }, filters).allowed, true);
  assert.equal(detectLocation({ location: "Brasil (Remoto)" }, filters).allowed, true);
  assert.equal(detectLocation({ location: "São José dos Pinhais, PR (Presencial)" }, filters).allowed, true);
  assert.equal(detectLocation({ location: "São Paulo, SP (Presencial)" }, filters).allowed, false);
  // "remote" na descrição não deve liberar vaga presencial em SP
  assert.equal(passesJobFilters({ title: "Senior Dev", location: "São Paulo (Presencial)", description: "remote friendly culture" }, filters).allowed, false);
});

test("pré-filtro do card", () => {
  assert.equal(passesCardFilters({ title: "Junior Dev", location: "Brasil (Remoto)" }, filters).allowed, false);
  assert.equal(passesCardFilters({ title: "Software Engineer", location: "Rio de Janeiro (Presencial)" }, filters).allowed, false);
  assert.equal(passesCardFilters({ title: "Software Engineer", location: "" }, filters).allowed, true);
});

test("intenções", () => {
  assert.equal(detectIntent("How would you rate your TypeScript proficiency?").intent, "typescript_experience");
  assert.equal(detectIntent("Qual sua pretensão salarial?").intent, "salary_expectation");
  assert.equal(detectIntent("How many years of work experience do you have?").intent, "years_of_experience");
  // anos com tecnologia específica NÃO deve cair no genérico
  const kube = detectIntent("How many years of work experience do you have with Kubernetes?");
  assert.notEqual(kube?.intent, "years_of_experience");
  assert.equal(detectIntent("Qual seu time do coração?"), null);
});

test("salário CLT x PJ", () => {
  const m = detectIntent("salary expectation");
  assert.equal(answerForIntent(m, { jobText: "Contratação PJ" }), "8000");
  assert.equal(answerForIntent(m, { jobText: "Regime CLT com benefícios" }), "6500");
  assert.equal(answerForIntent(m, { jobText: "" }), "6500");
});

test("escolha de opções", () => {
  const yn = [{ label: "Yes" }, { label: "No" }];
  assert.equal(chooseOption(yn, "Strong").label, "Yes");
  assert.equal(chooseOption(yn, "Yes – at least once").label, "Yes");
  assert.equal(chooseOption(yn, "No").label, "No");
  const sim = [{ label: "Sim" }, { label: "Não" }];
  assert.equal(chooseOption(sim, "Yes").label, "Sim");
  const ranges = [{ label: "Less than 1 year" }, { label: "1-2 years" }, { label: "3–5 years" }, { label: "6+ years" }];
  assert.equal(chooseOption(ranges, "3–5 years").label, "3–5 years");
  assert.equal(chooseOption(ranges, "x", { numeric: "7" }).label, "6+ years");
  assert.equal(chooseOption(ranges, "x", { numeric: "0" }).label, "Less than 1 year");
  const lvls = [{ label: "Beginner" }, { label: "Intermediate" }, { label: "Advanced" }];
  assert.equal(chooseOption(lvls, "Advanced").label, "Advanced");
  assert.equal(chooseOption(lvls, "Nada a ver"), null);
});

test("score usa palavras inteiras", () => {
  assert.ok(scoreJob({ title: "Senior Golang Developer", description: "Go, AWS, Docker" }) >= 65);
  assert.ok(scoreJob({ title: "Google Ads Manager", description: "good sales" }) < 65);
});

test("blacklist", () => {
  const data = { companies: ["ACME"], keywords: ["sales"] };
  assert.equal(isBlacklisted({ company: "Acme Corp", title: "Dev" }, data).blocked, true);
  assert.equal(isBlacklisted({ company: "X", title: "Dev", description: "wholesales" }, data).blocked, false);
});
