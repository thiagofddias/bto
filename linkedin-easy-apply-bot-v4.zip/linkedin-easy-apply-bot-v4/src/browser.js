import fs from "node:fs";
import { chromium } from "playwright";
import { config } from "./config.js";

export async function launchBrowser() {
  return chromium.launch({
    headless: config.headless,
    args: ["--start-maximized"]
  });
}

export async function newContext(browser, { useState = true } = {}) {
  const options = {
    viewport: config.headless ? { width: 1440, height: 900 } : null,
    acceptDownloads: true,
    locale: "pt-BR"
  };
  if (useState && fs.existsSync(config.stateFile)) options.storageState = config.stateFile;
  return browser.newContext(options);
}

export function isLoginUrl(url = "") {
  return /\/(login|authwall|checkpoint|uas\/login|signup)/i.test(url);
}

/** Abre o feed de vagas e confirma que a sessão salva ainda é válida. */
export async function ensureLoggedIn(page) {
  await page.goto("https://www.linkedin.com/jobs/", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2000);
  if (isLoginUrl(page.url())) return false;
  // Página pública de vagas tem botão "Entrar/Sign in" no topo.
  const signIn = page.locator('a[href*="/login"], a[data-tracking-control-name*="sign-in"]').first();
  if (await signIn.isVisible().catch(() => false)) return false;
  return true;
}
