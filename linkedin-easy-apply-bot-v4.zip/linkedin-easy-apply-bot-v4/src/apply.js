import { config } from "./config.js";
import { attachResume, fillStep, getModal, visibleErrors } from "./form.js";
import { findEasyApplyButton } from "./job.js";
import { ask, canPrompt, humanDelay, sleep } from "./utils.js";
import fs from "node:fs/promises";

const SUBMIT_RE = /(submit application|enviar candidatura|send application|submit|review your application|continue to next step|continue to review|review and submit|finalizar|concluir|send your application|apply now|avaliar|evaluate)/i;
const NEXT_RE = /(submit application|enviar candidatura|send application|submit|next|continue|continuar|avançar|avancar|review|revisar|próximo|proximo|review your application|continue to next step|continue to review|prosseguir|next step|seguinte|próximo passo|finalizar|concluir|review and submit|avaliar|evaluate)/i;
const SENT_RE = /application (was )?sent|your application was sent|candidatura (foi )?enviada|sua candidatura foi enviada|application submitted|your application has been submitted|submitted successfully|we are reviewing your application|estamos revisando sua candidatura|candidatura enviada|aplicação enviada|application review|sua candidatura na .* foi enviada|candidatura enviada/i;
const MAX_STEPS = 15;

export function isNextStepCandidate(text = "") {
  return NEXT_RE.test(String(text || ""));
}

export function looksLikeApplicationConfirmation(text = "") {
  return SENT_RE.test(String(text || ""));
}

async function captureModalDebug(page) {
  if (!config.debugModal) return;
  const base = `${config.root}/debug-modal`;
  await page.screenshot({ path: `${base}.png`, fullPage: false }).catch(() => {});
  await fs.writeFile(`${base}.html`, await page.content().catch(() => ""), "utf8").catch(() => {});
  const dialogs = await page.locator('[role="dialog"], [aria-modal="true"], .artdeco-modal').count().catch(() => 0);
  console.log(`   🧪 debug-modal: url=${page.url()} | abas=${page.context().pages().length} | diálogos=${dialogs}`);
  console.log(`   🧪 arquivos salvos: debug-modal.png e debug-modal.html`);
}

async function visibleButton(modal, re) {
  const buttons = modal.locator("button, a[role='button'], [role='button'], input[type='submit'], input[type='button']");
  const n = await buttons.count();
  for (let i = n - 1; i >= 0; i--) {
    const b = buttons.nth(i);
    if (!(await b.isVisible().catch(() => false))) continue;
    const text = `${(await b.innerText().catch(() => "")) || ""}`.trim();
    const aria = (await b.getAttribute("aria-label").catch(() => "")) || "";
    const title = (await b.getAttribute("title").catch(() => "")) || "";
    const value = (await b.getAttribute("value").catch(() => "")) || "";
    const dataName = (await b.getAttribute("data-control-name").catch(() => "")) || "";
    const combined = `${text} ${aria} ${title} ${value} ${dataName}`.trim();
    if (!combined) continue;
    if (re.test(combined) || re.test(text) || re.test(aria) || re.test(title) || re.test(value) || re.test(dataName)) return b;
  }

  const generic = modal.locator('[role="button"]').filter({ hasText: /next|continue|review|revisar|avançar|avancar|próximo|proximo|seguinte|submit|enviar|finalizar|concluir/i }).first();
  if (await generic.isVisible().catch(() => false)) return generic;

  const debugButtons = [];
  for (let i = 0; i < n; i++) {
    const b = buttons.nth(i);
    if ((await b.isVisible().catch(() => false))) {
      const text = `${(await b.innerText().catch(() => "")) || ""}`.trim();
      const aria = (await b.getAttribute("aria-label").catch(() => "")) || "";
      const title = (await b.getAttribute("title").catch(() => "")) || "";
      const value = (await b.getAttribute("value").catch(() => "")) || "";
      const dataName = (await b.getAttribute("data-control-name").catch(() => "")) || "";
      debugButtons.push(`${text || "(sem texto)"} | ${aria || "(sem aria-label)"} | ${title || "(sem title)"} | ${value || "(sem value)"} | ${dataName || "(sem data-control-name)"}`);
    }
  }
  if (debugButtons.length) {
    console.log(`   🧭 botões visíveis no modal: ${debugButtons.slice(0, 5).join(" ; ")}`);
  }

  return null;
}

async function progressSignature(modal) {
  return modal
    .evaluate((m) => {
      const bar = m.querySelector('progress, [role="progressbar"]');
      const h = m.querySelector("h3, h2")?.innerText || "";
      return `${bar?.value ?? bar?.getAttribute("aria-valuenow") ?? ""}|${h}|${m.querySelectorAll("input,select,textarea").length}`;
    })
    .catch(() => "");
}

async function modalStructureSnapshot(modal) {
  return modal
    .evaluate((m) => {
      const buttonDetails = [...m.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"]')]
        .map((el) => {
          const text = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120);
          const aria = (el.getAttribute("aria-label") || "").slice(0, 120);
          const value = (el.getAttribute("value") || "").slice(0, 120);
          const type = el.getAttribute("type") || el.getAttribute("role") || "";
          return { text, aria, value, type };
        })
        .slice(0, 12);

      const text = (m.innerText || "").replace(/\s+/g, " ").trim().slice(0, 1200);
      const h = (m.outerHTML || "").slice(0, 4000);
      return {
        text,
        html: h,
        fieldCount: m.querySelectorAll("input, select, textarea").length,
        fileCount: m.querySelectorAll('input[type="file"]').length,
        buttons: buttonDetails
      };
    })
    .catch(() => ({ text: "", html: "", fieldCount: 0, fileCount: 0, buttons: [] }));
}

/** Fecha o modal e descarta o rascunho (ou apenas fecha a tela de "candidatura enviada"). */
export async function closeModal(page) {
  for (let i = 0; i < 3; i++) {
    const modal = await getModal(page);
    if (!modal) return;
    const dismiss = modal
      .locator('button[aria-label*="Dismiss" i], button[aria-label*="Fechar" i], button[aria-label*="Descartar" i], button[data-test-modal-close-btn]')
      .first();
    if (await dismiss.isVisible().catch(() => false)) await dismiss.click().catch(() => {});
    else await page.keyboard.press("Escape").catch(() => {});
    await sleep(900);

    const discard = page.getByRole("button", { name: /^(discard|descartar)$/i }).first();
    if (await discard.isVisible().catch(() => false)) {
      await discard.click().catch(() => {});
      await sleep(800);
    }
  }
}

async function wasSent(page) {
  const body = await page.locator("body").innerText().catch(() => "");
  const normalized = `${body}\n${await page.title().catch(() => "")}`;
  if (looksLikeApplicationConfirmation(normalized)) return true;

  const modal = await getModal(page);
  if (!modal) return false;

  const success = await modal.evaluate((m) => {
    const text = (m.innerText || "").replace(/\s+/g, " ").trim();
    return /sua candidatura .* foi enviada|your application .* was sent|application submitted|we are reviewing your application|candidatura enviada/i.test(text);
  }).catch(() => false);

  if (success) return true;

  const concluded = modal.getByRole("button", { name: /concluído|concluido|done|done/ }).first();
  return (await concluded.isVisible().catch(() => false));
}

async function reviewAndMaybeSubmit(page, submit) {
  if (!config.reviewBeforeSubmit) {
    await submit.click();
    console.log("   ⏳ aguardando resposta do LinkedIn antes de fechar o modal...");
    for (let i = 0; i < 10; i++) {
      await sleep(1500);
      if (await wasSent(page)) return { status: "submitted_automatically", reason: "enviada automaticamente" };
      const modal = await getModal(page);
      if (!modal) {
        console.log("   ⏱️  o modal saiu da tela; deixando a página visível para confirmar o estado final do envio...");
        await sleep(6000);
        return { status: "needs_review", reason: "o modal saiu após clicar em enviar; resultado não confirmou" };
      }
    }
    return { status: "needs_review", reason: "botão de envio clicado, mas não foi possível confirmar o envio" };
  }

  if (!canPrompt() || config.headless) {
    return { status: "ready_to_submit", reason: "formulário preenchido; envio final não automático (revisão indisponível)" };
  }

  console.log("\n👀 Formulário completo. Revise no navegador.");
  console.log("   Se quiser enviar, clique você mesmo em 'Enviar candidatura'.");
  await ask("   Pressione ENTER aqui quando terminar (enviando ou não)... ");
  await sleep(1000);

  if (await wasSent(page)) return { status: "submitted_manually", reason: "enviada por você" };
  const modal = await getModal(page);
  if (!modal) return { status: "unknown", reason: "modal fechado; confira em 'Minhas vagas'" };
  return { status: "not_submitted", reason: "revisada e não enviada" };
}

export async function applyToJob(page, job) {
  const button = await findEasyApplyButton(page);
  if (!button) return { status: "not_easy_apply", reason: "botão de Candidatura simplificada não encontrado" };

  const context = page.context();
  await button.click();
  let modalAppeared = false;
  let formPage = page;
  for (let attempt = 0; attempt < 80 && !modalAppeared; attempt++) {
    for (const candidate of context.pages()) {
      if (await getModal(candidate)) {
        formPage = candidate;
        modalAppeared = true;
        break;
      }
    }
    if (!modalAppeared) await sleep(250);
  }
  if (!modalAppeared) {
    await captureModalDebug(formPage);
    return { status: "needs_review", reason: "modal do Easy Apply não abriu" };
  }
  await humanDelay(800, 1500);

  let resumeDone = false;
  let lastSig = "";
  let sameCount = 0;

  try {
    for (let step = 0; step < MAX_STEPS; step++) {
      const modal = await getModal(formPage);
      if (!modal) return { status: "needs_review", reason: "modal fechou inesperadamente" };

      if (!resumeDone) resumeDone = await attachResume(formPage, modal);

      const result = await fillStep(formPage, modal, job);
      if (!result.ok) {
        return {
          status: "skipped_missing_answer",
          reason: `vaga pulada: ${result.unknown.map((f) => `"${f.question.slice(0, 50)}"`).join(", ")}`
        };
      }

      const submit = await visibleButton(modal, SUBMIT_RE);
      if (submit) return await reviewAndMaybeSubmit(formPage, submit);

      const next = await visibleButton(modal, NEXT_RE);
      if (!next) {
        const snapshot = await modalStructureSnapshot(modal);
        const bodyText = `${snapshot.text || ""}`.toLowerCase();
        if (/sua candidatura .* foi enviada|your application .* was sent|candidatura enviada|application submitted/i.test(bodyText)) {
          return { status: "submitted_automatically", reason: "confirmação de envio detectada no modal final" };
        }

        console.log("   🧩 estrutura do modal no ponto em que o bot travou:", JSON.stringify({
          fieldCount: snapshot.fieldCount,
          fileCount: snapshot.fileCount,
          buttons: snapshot.buttons,
          textPreview: snapshot.text
        }, null, 2));
        await captureModalDebug(formPage);
        await sleep(12000);
        return { status: "needs_review", reason: "modal sem botão de avanço; estrutura do LinkedIn foi capturada para diagnóstico" };
      }

      const before = await progressSignature(modal);
      await next.click();
      await humanDelay(900, 1800);

      const errors = await visibleErrors(modal);
      const after = await progressSignature(modal);

      if (after === before) {
        sameCount++;
        if (errors.length && sameCount >= 2) {
          return { status: "needs_review", reason: `validação: ${errors.slice(0, 2).join(" / ")}` };
        }
        if (sameCount >= 3) return { status: "needs_review", reason: "formulário não avançou" };
      } else {
        sameCount = 0;
      }
      lastSig = after;
    }
    return { status: "needs_review", reason: `limite de ${MAX_STEPS} etapas atingido (${lastSig})` };
  } finally {
    const modal = await getModal(formPage);
    if (modal) {
      console.log("   ⏱️  deixando a tela visível por mais alguns segundos para confirmar o resultado do envio...");
      await sleep(12000);
      const stillVisible = await getModal(formPage);
      if (stillVisible) await closeModal(formPage);
    }
  }
}
