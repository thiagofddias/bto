import fs from "node:fs";
import { config } from "./config.js";
import { normalize, hasTerm } from "./utils.js";

let cache = null;
function readBlacklist() {
  if (!cache) {
    try {
      cache = JSON.parse(fs.readFileSync(config.blacklistFile, "utf8"));
    } catch {
      cache = { companies: [], keywords: [] };
    }
  }
  return cache;
}

export function isBlacklisted({ company = "", title = "", description = "" }, data = readBlacklist()) {
  const companyText = normalize(company);
  const allText = `${title} ${description}`;

  for (const item of data.companies || []) {
    const c = normalize(item);
    if (c && companyText.includes(c)) return { blocked: true, reason: `empresa na blacklist: ${item}` };
  }

  for (const item of data.keywords || []) {
    if (hasTerm(allText, item)) return { blocked: true, reason: `keyword na blacklist: ${item}` };
  }

  return { blocked: false };
}
