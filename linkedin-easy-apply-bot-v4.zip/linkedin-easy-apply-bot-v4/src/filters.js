import { config } from "./config.js";
import { hasAnyTerm, countTerm, normalize } from "./utils.js";

// Sinônimos de cada nível. "mid senior" é o "Mid-Senior level / Pleno-sênior" do LinkedIn.
const LEVEL_TERMS = {
  trainee: ["trainee"],
  pleno: ["pleno", "mid level", "mid senior", "pleno senior"],
  senior: ["senior", "sr", "mid senior", "pleno senior"],
  junior: ["junior", "jr", "entry level", "assistente"],
  estagio: ["estagio", "estagiario", "estagiaria", "intern", "internship"]
};

function termsFor(levels) {
  return [...new Set(levels.flatMap((lvl) => LEVEL_TERMS[normalize(lvl)] || [lvl]))];
}

function classify(text, allowedTerms, excludedTerms) {
  const allowed = hasAnyTerm(text, allowedTerms);
  const excluded = hasAnyTerm(text, excludedTerms);
  if (allowed) return { decided: true, allowed: true, term: allowed };
  if (excluded) return { decided: true, allowed: false, term: excluded };
  return { decided: false };
}

/**
 * Detecta o nível em camadas: título → chips/critérios do LinkedIn → descrição.
 * Na descrição conta ocorrências (frases como "vai mentorar juniores" não derrubam uma vaga sênior).
 */
export function detectLevel(job, filters = config.filters) {
  const allowedTerms = termsFor(filters.allowedLevels);
  const excludedTerms = [...new Set([...(filters.excludedLevels || []), ...termsFor(["junior", "estagio"])])]
    .filter((t) => !allowedTerms.some((a) => normalize(a) === normalize(t)));

  for (const [source, text] of [
    ["título", job.title],
    ["LinkedIn", `${job.criteria || ""} ${job.topCard || ""}`]
  ]) {
    if (!text) continue;
    const r = classify(text, allowedTerms, excludedTerms);
    if (r.decided) {
      return r.allowed
        ? { allowed: true, level: r.term, source }
        : { allowed: false, level: "excluded", reason: `nível "${r.term}" (${source})`, source };
    }
  }

  if (job.description) {
    const a = allowedTerms.reduce((s, t) => s + countTerm(job.description, t), 0);
    const e = excludedTerms.reduce((s, t) => s + countTerm(job.description, t), 0);
    if (a > 0 && a >= e) return { allowed: true, level: hasAnyTerm(job.description, allowedTerms), source: "descrição" };
    if (e > a) return { allowed: false, level: "excluded", reason: "descrição indica júnior/estágio", source: "descrição" };
  }

  return { allowed: false, level: "unknown", reason: "nível não identificado" };
}

const REMOTE_TERMS = ["remote", "remoto", "remota", "home office", "trabalho remoto", "anywhere"];

export function detectLocation(job, filters = config.filters) {
  const allowed = filters.allowedLocations || [];
  if (!allowed.length) return { allowed: true, location: "qualquer" };

  // Só olha localização e cabeçalho da vaga, não a descrição inteira.
  const text = `${job.location || ""} ${job.workplace || ""} ${(job.topCard || "").slice(0, 800)}`;
  if (!normalize(text)) return { allowed: true, location: "desconhecida", undecided: true };

  const remoteAllowed = allowed.some((l) => REMOTE_TERMS.includes(normalize(l)));
  if (remoteAllowed && hasAnyTerm(text, REMOTE_TERMS)) return { allowed: true, location: "remoto" };

  const city = allowed
    .filter((l) => !REMOTE_TERMS.includes(normalize(l)))
    .sort((a, b) => b.length - a.length)
    .find((l) => hasAnyTerm(text, [l]));
  if (city) return { allowed: true, location: normalize(city) };

  return { allowed: false, location: "other", reason: `localização fora das permitidas (${job.location || "?"})` };
}

/** Filtro rápido só com dados do card da busca (evita abrir páginas à toa). */
export function passesCardFilters(job, filters = config.filters) {
  const loc = detectLocation({ location: job.location }, filters);
  if (!loc.allowed) return { allowed: false, reason: loc.reason };

  const lvl = classify(job.title || "", termsFor(filters.allowedLevels), [
    ...(filters.excludedLevels || []),
    ...termsFor(["junior", "estagio"])
  ].filter((t) => !termsFor(filters.allowedLevels).includes(t)));
  if (lvl.decided && !lvl.allowed) return { allowed: false, reason: `nível "${lvl.term}" no título` };

  return { allowed: true };
}

export function passesJobFilters(job, filters = config.filters) {
  const level = detectLevel(job, filters);
  if (!level.allowed && (level.level === "excluded" || filters.excludeUnknownLevel)) {
    return { allowed: false, reason: level.reason, level: level.level, location: null };
  }

  const location = detectLocation(job, filters);
  if (!location.allowed) {
    return { allowed: false, reason: location.reason, level: level.level, location: location.location };
  }

  return { allowed: true, reason: "ok", level: level.level, location: location.location };
}
