import fs from "node:fs";
import { config } from "./config.js";
import {
  detectIntent,
  findClosestIntent,
  answerForIntent,
  appendUnanswered,
  learnAnswer,
  intentIdFromQuestion,
  readAnswers,
  recordSkippedJob
} from "./storage.js";
import { chooseOption, numericValue, isYes } from "./options.js";
import { ask, canPrompt, normalize, sleep } from "./utils.js";

export const MODAL_SELECTOR = [
  '.jobs-easy-apply-modal',
  '[data-test-modal-id="easy-apply-modal"]',
  '[data-test-modal-container="easy-apply-modal"]',
  '[aria-modal="true"]',
  '[aria-labelledby*="easy-apply" i]',
  '.artdeco-modal',
  '[class*="easy-apply"]',
  'section[role="dialog"]',
  'div[role="dialog"]'
].join(', ');

/** Retorna o modal do Easy Apply visível (ou o último diálogo visível). */
export async function getModal(page) {
  const candidates = [];

  for (const sel of [MODAL_SELECTOR]) {
    const all = page.locator(sel);
    const n = await all.count();
    for (let i = n - 1; i >= 0; i--) {
      const m = all.nth(i);
      if (!(await m.isVisible().catch(() => false))) continue;
      const score = await m.evaluate((el) => {
        const text = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
        const fieldCount = el.querySelectorAll("input, select, textarea").length;
        const buttonCount = el.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"]').length;
        const pdfLike = /PDF\s+.*\.pdf/i.test(text) && fieldCount <= 3;
        const titleBonus = /Candidate-se à empresa|Contact info|Additional Questions|Mobile phone number|Resume|Curr[ií]culo/i.test(text) ? 20 : 0;
        return titleBonus + fieldCount * 5 + buttonCount * 2 + (pdfLike ? -50 : 0);
      }).catch(() => 0);
      candidates.push({ element: m, score });
    }
  }

  if (candidates.length) {
    candidates.sort((a, b) => b.score - a.score);
    const best = candidates[0];
    if (best.score > 0) return best.element;
    return candidates[0].element;
  }

  // O LinkedIn também pode renderizar o modal sem role, data-test ou classe estável.
  for (const text of [/Mobile phone number/i, /Contact info/i, /Candidate-se à empresa/i]) {
    const marker = page.getByText(text).last();
    if (!(await marker.isVisible().catch(() => false))) continue;
    const container = marker.locator(
      'xpath=ancestor::*[.//button and (.//input or .//select or .//textarea)][1]'
    );
    if (await container.isVisible().catch(() => false)) return container;
  }

  return null;
}

// ---------------- currículo ----------------

export async function attachResume(page, modal) {
  if (config.uploadResume === "never" || !fs.existsSync(config.resumePath)) return false;

  let inputs = modal.locator('input[type="file"]');
  let count = await inputs.count();
  if (!count) {
    const upload = modal.getByRole("button", { name: /carregar currículo|upload resume|add resume/i }).first();
    if (await upload.isVisible().catch(() => false)) {
      const chooserPromise = page.waitForEvent("filechooser", { timeout: 3000 }).catch(() => null);
      await upload.click().catch(() => {});
      const chooser = await chooserPromise;
      if (chooser) {
        await chooser.setFiles(config.resumePath);
        await sleep(1500);
        console.log("   📎 curriculo.pdf enviado");
        return true;
      }
      await sleep(500);
      inputs = modal.locator('input[type="file"]');
      count = await inputs.count();
    }
  }
  if (!count) return false;

  for (let i = 0; i < count; i++) {
    const input = inputs.nth(i);
    const info = await input.evaluate((el) => {
      const section = el.closest("form, section, .jobs-document-upload-redesign-card__container, div") || el.parentElement;
      const box = el.closest(".jobs-easy-apply-form-section__grouping, .js-jobs-document-upload__container, section, form") || section;
      const text = (box?.innerText || "") + " " + (el.getAttribute("aria-label") || "") + " " + (el.id || "");
      const selected = Boolean(
        box?.querySelector(
          '[class*="--selected"], [aria-checked="true"], input[type="radio"]:checked, [aria-label*="Selected" i], [aria-label*="Selecionado" i]'
        )
      );
      return { text, selected };
    }).catch(() => ({ text: "", selected: false }));

    const isCover = /cover letter|carta de apresenta/i.test(info.text);
    const isResume = /resume|curr[ií]culo|\bcv\b/i.test(info.text);
    if (isCover && !isResume) continue;
    if (config.uploadResume === "auto" && info.selected) return false;

    try {
      await input.setInputFiles(config.resumePath);
      await sleep(1500);
      console.log("   📎 curriculo.pdf enviado");
      return true;
    } catch {}
  }
  return false;
}

// ---------------- leitura dos campos ----------------

/**
 * Varre o modal e devolve cada pergunta com tipo, texto, opções e se já está preenchida.
 * Cada elemento recebe um data-bot-id para ser localizado depois.
 */
export async function scanFields(modal) {
  return modal.evaluate((root) => {
    let seq = Number(root.getAttribute("data-bot-seq") || 0);
    const id = (el) => {
      if (!el.dataset.botId) el.dataset.botId = `b${++seq}`;
      return el.dataset.botId;
    };
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const clean = (t) => {
      const out = [];
      for (const l of (t || "").split("\n").map((x) => x.trim()).filter(Boolean)) {
        if (out[out.length - 1] !== l) out.push(l);
      }
      return out.join(" ").replace(/\s+/g, " ").trim();
    };
    const labelOf = (el) => {
      if (el.id) {
        const l = root.querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (l && clean(l.innerText)) return clean(l.innerText);
      }
      const wrap = el.closest("label");
      if (wrap && clean(wrap.innerText)) return clean(wrap.innerText);
      const by = el.getAttribute("aria-labelledby");
      if (by) {
        const t = by.split(/\s+/).map((x) => document.getElementById(x)?.innerText || "").join(" ");
        if (clean(t)) return clean(t);
      }
      return clean(el.getAttribute("aria-label") || el.getAttribute("placeholder") || "");
    };
    const requiredOf = (els, container, text) =>
      els.some((el) => el.required || el.getAttribute("aria-required") === "true") ||
      Boolean(container?.querySelector('[aria-required="true"], [required], [data-test-checkbox-form-required], .fb-dash-form-element__label-title--is-required')) ||
      /\*\s*$|\brequired\b|obrigat[óo]ri/i.test(text);
    const containerOf = (el) =>
      el.closest('[data-test-form-element], .fb-dash-form-element, .jobs-easy-apply-form-element, .jobs-easy-apply-form-section__grouping, .artdeco-text-input, .fb-form-element');

    const fields = [];
    const handled = new Set();

    for (const fs of root.querySelectorAll("fieldset")) {
      const inputs = [...fs.querySelectorAll('input[type="radio"], input[type="checkbox"]')];
      if (!inputs.length || !visible(fs)) continue;
      inputs.forEach((i) => handled.add(i));
      const legend = fs.querySelector("legend");
      const question = clean(legend ? legend.innerText : fs.getAttribute("aria-label") || "");
      fields.push({
        botId: id(fs),
        kind: inputs[0].type === "radio" ? "radio" : "checkbox",
        question,
        options: inputs.map((i) => ({ botId: id(i), label: labelOf(i), value: i.value })),
        required: requiredOf(inputs, fs, question),
        filled: inputs.some((i) => i.checked)
      });
    }

    for (const el of root.querySelectorAll("input, textarea, select")) {
      if (handled.has(el)) continue;
      const type = (el.getAttribute("type") || "").toLowerCase();
      if (["hidden", "file", "submit", "button", "radio", "image", "reset"].includes(type)) continue;
      if (!visible(el) && type !== "checkbox") continue;
      if (type === "checkbox" && !visible(el) && !visible(el.closest("label") || root.querySelector(`label[for="${CSS.escape(el.id || "_")}"]`))) continue;
      if (el.disabled || el.readOnly) continue;

      const container = containerOf(el);
      const question = labelOf(el) || clean(container?.querySelector("label, legend, span")?.innerText || "");

      if (type === "checkbox") {
        fields.push({ botId: id(el), kind: "single-checkbox", question, options: [], required: requiredOf([el], null, question), filled: el.checked });
        continue;
      }

      if (el.tagName === "SELECT") {
        const placeholder = (o) => !o || !o.value || /select an option|selecione|selecionar|escolha|choose/i.test(o.textContent || "");
        fields.push({
          botId: id(el),
          kind: "select",
          question,
          options: [...el.options].filter((o) => !placeholder(o)).map((o) => ({ value: o.value, label: clean(o.textContent) })),
          required: requiredOf([el], container, question),
          filled: !placeholder(el.options[el.selectedIndex])
        });
        continue;
      }

      const kind =
        el.tagName === "TEXTAREA"
          ? "textarea"
          : el.getAttribute("role") === "combobox" || el.getAttribute("aria-autocomplete") === "list"
            ? "combobox"
            : type === "number" || /numeric/i.test(el.id || "") || ["numeric", "decimal"].includes(el.inputMode)
              ? "number"
              : "text";
      fields.push({ botId: id(el), kind, question, options: [], required: requiredOf([el], container, question), filled: Boolean(el.value.trim()) });
    }

    root.setAttribute("data-bot-seq", String(seq));
    return fields;
  });
}

// ---------------- preenchimento ----------------

async function clickOption(modal, botId) {
  const input = modal.locator(`[data-bot-id="${botId}"]`);
  await input.evaluate((el) => {
    const label = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`) : el.closest("label");
    (label || el).click();
  });
  await sleep(200);
  if (!(await input.isChecked().catch(() => false))) await input.check({ force: true }).catch(() => {});
  return input.isChecked().catch(() => false);
}

export async function fillField(page, modal, field, answer, entry = {}) {
  const loc = modal.locator(`[data-bot-id="${field.botId}"]`);

  switch (field.kind) {
    case "text":
    case "textarea":
      await loc.fill(String(answer));
      return true;

    case "number": {
      const n = numericValue(answer, entry);
      if (n == null) return false;
      await loc.fill(n);
      return true;
    }

    case "combobox": {
      await loc.fill("");
      await loc.pressSequentially(String(answer), { delay: 60 });
      await sleep(1500);
      const opt = page.locator('[role="listbox"] [role="option"], .basic-typeahead__selectable, .search-typeahead-v2__hit').first();
      if (await opt.isVisible().catch(() => false)) await opt.click();
      else {
        await loc.press("ArrowDown").catch(() => {});
        await loc.press("Enter").catch(() => {});
      }
      return true;
    }

    case "select": {
      const o = chooseOption(field.options, answer, entry);
      if (!o) return false;
      await loc.selectOption(o.value);
      return true;
    }

    case "radio":
    case "checkbox": {
      const o = chooseOption(field.options, answer, entry);
      if (!o) return false;
      return clickOption(modal, o.botId);
    }

    case "single-checkbox":
      if (!isYes(answer)) return true;
      return clickOption(modal, field.botId);

    default:
      return false;
  }
}

async function tryAnswer(page, modal, field, job, answers) {
  const match = detectIntent(field.question, answers);
  if (match) {
    const answer = answerForIntent(match, {
      jobText: `${job.title} ${job.company} ${job.location} ${job.topCard || ""} ${job.description || ""}`
    });
    if (answer == null) return { ok: false, intent: match.intent };

    try {
      const ok = await fillField(page, modal, field, answer, match.entry);
      const shown = field.kind === "number" ? numericValue(answer, match.entry) : answer;
      if (ok) console.log(`   ✏️  "${field.question.slice(0, 70)}" → ${shown} [${match.intent}]`);
      return { ok, intent: match.intent, note: ok ? "" : `resposta "${answer}" não bate com as opções` };
    } catch (err) {
      return { ok: false, intent: match.intent, note: err.message.split("\n")[0] };
    }
  }

  const nearest = findClosestIntent(field.question, answers);
  if (nearest && nearest.score >= 0.45) {
    const answer = answerForIntent(nearest, {
      jobText: `${job.title} ${job.company} ${job.location} ${job.topCard || ""} ${job.description || ""}`
    });
    if (answer != null) {
      try {
        const ok = await fillField(page, modal, field, answer, nearest.entry);
        const shown = field.kind === "number" ? numericValue(answer, nearest.entry) : answer;
        if (ok) console.log(`   ✨ "${field.question.slice(0, 70)}" → ${shown} [${nearest.intent}] (match próximo)`);
        return { ok, intent: nearest.intent, note: ok ? "" : `resposta "${answer}" não bate com as opções`, nearest: true };
      } catch (err) {
        return { ok: false, intent: nearest.intent, note: err.message.split("\n")[0], nearest: true };
      }
    }
  }

  return { ok: false, intent: nearest?.intent || null, nearest: Boolean(nearest), score: nearest?.score ?? 0 };
}

/** Pergunta no terminal e salva a resposta em answers.json. */
async function askUser(field, job) {
  if (!config.interactiveAnswers || !canPrompt()) return null;

  console.log(`\n❓ Pergunta desconhecida (${job.company} — ${job.title}):`);
  console.log(`   ${field.question}`);
  if (field.options.length) console.log(`   Opções: ${field.options.map((o) => o.label).join(" | ")}`);

  const reply = await ask("   Resposta (ENTER = pular vaga | m = eu preencho no navegador): ");
  if (!reply) return null;
  if (reply.toLowerCase() === "m") {
    await ask("   Preencha no navegador e pressione ENTER... ");
    return "manual";
  }

  const intent = intentIdFromQuestion(field.question);
  learnAnswer(intent, reply, [normalize(field.question)]);
  console.log(`   💾 salvo em answers.json como "${intent}"`);
  return reply;
}

/**
 * Preenche a etapa atual do formulário.
 * Retorna ok=false se sobrar pergunta obrigatória sem resposta.
 */
export async function fillStep(page, modal, job) {
  const fields = await scanFields(modal);
  const blocking = [];

  for (const field of fields) {
    if (field.filled) continue;
    if (!field.question) {
      if (field.required) blocking.push(field);
      continue;
    }

    if (config.linkedinProfile && /linkedin profile/i.test(field.question)) {
      await fillField(page, modal, field, config.linkedinProfile);
      console.log(`   ✏️  "${field.question.slice(0, 70)}" → perfil configurado [linkedin_profile]`);
      continue;
    }

    if (config.phoneNumber && field.kind === "text" && /\b(?:mobile|phone|telefone|celular)\b/i.test(normalize(field.question))) {
      await fillField(page, modal, field, config.phoneNumber);
      console.log(`   ✏️  "${field.question.slice(0, 70)}" → telefone configurado [phone_number]`);
      continue;
    }

    let result = await tryAnswer(page, modal, field, job, readAnswers());
    if (result.ok) continue;

    if (!field.required) {
      console.log(`   ↷ opcional ignorada: "${field.question.slice(0, 70)}"`);
      continue;
    }

    const reply = await askUser(field, job);
    if (reply === "manual") continue;
    if (reply) {
      result = await tryAnswer(page, modal, field, job, readAnswers());
      if (result.ok) continue;
    }

    const skipReason = result.nearest
      ? `possível resposta semelhante encontrada, mas sem confiança suficiente (score ${Number(result.score || 0).toFixed(2)})`
      : "sem resposta confiável";

    appendUnanswered({
      question: field.question,
      options: field.options.map((o) => o.label),
      jobTitle: job.title,
      company: job.company,
      url: job.url,
      intentGuess: result.intent || "",
      note: result.note || skipReason
    });
    recordSkippedJob({
      question: field.question,
      options: field.options.map((o) => o.label),
      jobTitle: job.title,
      company: job.company,
      url: job.url,
      intentGuess: result.intent || "",
      reason: skipReason,
      score: Number(result.score || 0)
    });
    blocking.push(field);
  }

  return { ok: blocking.length === 0, unknown: blocking, skipped: blocking.length > 0 };
}

/** Mensagens de erro de validação visíveis no modal. */
export async function visibleErrors(modal) {
  const errs = modal.locator('.artdeco-inline-feedback--error, [data-test-form-element-error-messages], [role="alert"]');
  const texts = [];
  const n = await errs.count();
  for (let i = 0; i < n; i++) {
    const e = errs.nth(i);
    if (await e.isVisible().catch(() => false)) {
      const t = (await e.innerText().catch(() => "")).trim();
      if (t) texts.push(t);
    }
  }
  return texts;
}
