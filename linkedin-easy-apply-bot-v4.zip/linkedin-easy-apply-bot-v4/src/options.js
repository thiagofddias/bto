import { normalize, hasTerm } from "./utils.js";

const YES = ["yes", "sim", "y", "s"];
const NO = ["no", "nao", "n"];
const NEGATIVE_RE = /^(no|nao|never|nunca|none|nenhum|nenhuma|0)\b/;

export function numericValue(answer, entry = {}) {
  if (entry.numeric != null) return String(entry.numeric);
  const m = String(answer ?? "").replace(/\./g, "").match(/\d+(?:,\d+)?/);
  return m ? m[0].replace(",", ".") : null;
}

function rangeMatch(label, n) {
  const l = normalize(label);
  let m = l.match(/(\d+)\s*(?:and|to|ate|a|e)?\s*(\d+)/);
  if (m && Number(m[1]) < Number(m[2])) return n >= Number(m[1]) && n <= Number(m[2]);
  m = String(label).match(/(\d+)\s*\+/) || l.match(/(?:more than|mais de|over|acima de)\s*(\d+)/);
  if (m) return n >= Number(m[1]);
  m = l.match(/(?:less than|menos de|under|ate)\s*(\d+)/);
  if (m) return n < Number(m[1]);
  m = l.match(/^(\d+)(?: years?| anos?)?$/);
  if (m) return n === Number(m[1]);
  return false;
}

/**
 * Escolhe a opção (radio/select) que corresponde à resposta.
 * Ordem: igual → contém → faixa numérica → Sim/Não.
 */
export function chooseOption(options = [], answer, entry = {}) {
  const valid = options.filter((o) => normalize(o.label));
  if (!valid.length || answer == null) return null;
  const a = normalize(answer);

  let found = valid.find((o) => normalize(o.label) === a);
  if (found) return found;

  found = valid.find((o) => {
    const l = normalize(o.label);
    return (l.length > 1 && hasTerm(a, l)) || (a.length > 1 && hasTerm(l, a));
  });
  if (found) return found;

  const n = Number(numericValue(answer, entry));
  if (Number.isFinite(n) && numericValue(answer, entry) != null) {
    found = valid.find((o) => rangeMatch(o.label, n));
    if (found) return found;
  }

  const yes = valid.find((o) => YES.includes(normalize(o.label)));
  const no = valid.find((o) => NO.includes(normalize(o.label)));
  if (yes || no) {
    if (entry.yesNo) return normalize(entry.yesNo).startsWith("n") ? no : yes;
    return NEGATIVE_RE.test(a) ? no || null : yes || null;
  }

  return null;
}

export function isYes(answer) {
  const a = normalize(answer);
  return a && !NEGATIVE_RE.test(a);
}
