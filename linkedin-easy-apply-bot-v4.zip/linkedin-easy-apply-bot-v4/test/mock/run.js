// Teste de ponta a ponta sem LinkedIn: roda o fluxo real contra uma página imitando o Easy Apply.
// Uso: npm run test:mock
import path from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";
import { loadJobDetails } from "../../src/job.js";
import { applyToJob } from "../../src/apply.js";
import { passesJobFilters } from "../../src/filters.js";
import { scoreJob } from "../../src/scoring.js";

const url = pathToFileURL(path.resolve("test/mock/job.html")).toString();
const browser = await chromium.launch({ headless: true });
const page = await (await browser.newContext()).newPage();

try {
  const job = await loadJobDetails(page, { jobId: "mock", title: "Senior Backend Engineer", company: "ACME", location: "Curitiba, Paraná, Brasil (Híbrido)", url });
  console.log("detalhes:", { hasEasyApply: job.hasEasyApply, alreadyApplied: job.alreadyApplied, filtro: passesJobFilters(job), score: scoreJob(job) });

  const result = await applyToJob(page, job);
  const state = await page.evaluate(() => ({ answers: window.answers, uploaded: window.uploaded, sent: !!window.sent, discarded: !!window.discarded }));
  console.log("resultado:", result);
  console.log("estado da página:", state);

  const ok =
    result.status === "ready_to_submit" &&
    state.uploaded === "curriculo.pdf" &&
    state.answers.deg === "Yes" &&
    state.answers["numeric-yrs"] === "3" &&
    state.answers.eng === "Intermediate" &&
    state.answers.sal === "8000" &&
    state.answers.r === "Yes" &&
    !state.sent &&
    state.discarded;
  console.log(ok ? "\n✅ MOCK OK" : "\n❌ MOCK FALHOU");
  process.exitCode = ok ? 0 : 1;
} finally {
  await browser.close();
}
