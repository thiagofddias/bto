import { config } from "./config.js";
import { attachResume, fillStep, getModal, visibleErrors } from "./form.js";
import { findEasyApplyButton } from "./job.js";
import { ask, canPrompt, humanDelay, sleep } from "./utils.js";

const SUBMIT_RE = /submit application|enviar candidatura/i;
const NEXT_RE = /^(next|continue|continuar|avançar|avancar|review|revisar|próximo|proximo)\b/i;
const SENT_RE = /application (was )?sent|your application was sent|candidatura (foi )?enviada|sua candidatura foi enviada/i;
const MAX_STEPS = 15;

async function visibleButton(modal, re) {
  const buttons = modal.locator("button");
  const n = await buttons.count();
  for (let i = n - 1; i >= 0; i--) {
    const b = buttons.nth(i);
    if (!(await b.isVisible().catch(() => false))) continue;
    const text = `${(await b.innerText().catch(() => "")) || ""}`.trim();
    const aria = (await b.getAttribute("aria-label").catch(() => "")) || "";
    if (re.test(text) || re.test(aria)) return b;
  }
  return null;
}

async function progressSignature(modal) {
  return modal
    .evaluate((m) => {
      const bar = m.querySelector('progress, [role="progressbar"]');
      const h = m.querySelector("h3, h2")?.innerText || "";
      return `${bar?.value ?? bar?.getAttribute("aria-valuenow") ?? ""}|${h}|${m.querySelectorAll("input,select,textarea").length}`;
    })
    .catch(() => "");
}

/** Fecha o modal e descarta o rascunho (ou apenas fecha a tela de "candidatura enviada"). */
export async function closeModal(page) {
  for (let i = 0; i < 3; i++) {
    const modal = await getModal(page);
    if (!modal) return;
    const dismiss = modal
      .locator('button[aria-label*="Dismiss" i], button[aria-label*="Fechar" i], button[aria-label*="Descartar" i], button[data-test-modal-close-btn]')
      .first();
    if (await dismiss.isVisible().catch(() => false)) await dismiss.click().catch(() => {});
    else await page.keyboard.press("Escape").catch(() => {});
    await sleep(900);

    const discard = page.getByRole("button", { name: /^(discard|descartar)$/i }).first();
    if (await discard.isVisible().catch(() => false)) {
      await discard.click().catch(() => {});
      await sleep(800);
    }
  }
}

async function wasSent(page) {
  const body = await page.locator("body").innerText().catch(() => "");
  return SENT_RE.test(body);
}

async function reviewAndMaybeSubmit(page) {
  if (!config.reviewBeforeSubmit || !canPrompt() || config.headless) {
    return { status: "ready_to_submit", reason: "formulário preenchido; envio final não automático (revisão desativada)" };
  }

  console.log("\n👀 Formulário completo. Revise no navegador.");
  console.log("   Se quiser enviar, clique você mesmo em 'Enviar candidatura'.");
  await ask("   Pressione ENTER aqui quando terminar (enviando ou não)... ");
  await sleep(1000);

  if (await wasSent(page)) return { status: "submitted_manually", reason: "enviada por você" };
  const modal = await getModal(page);
  if (!modal) return { status: "unknown", reason: "modal fechado; confira em 'Minhas vagas'" };
  return { status: "not_submitted", reason: "revisada e não enviada" };
}

export async function applyToJob(page, job) {
  const button = await findEasyApplyButton(page);
  if (!button) return { status: "not_easy_apply", reason: "botão de Candidatura simplificada não encontrado" };

  await button.click();
  const modalAppeared = await page
    .locator(`${'.jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"]'}, div[role="dialog"]`)
    .first()
    .waitFor({ state: "visible", timeout: 10000 })
    .then(() => true)
    .catch(() => false);
  if (!modalAppeared) return { status: "needs_review", reason: "modal do Easy Apply não abriu" };
  await humanDelay(800, 1500);

  let resumeDone = false;
  let lastSig = "";
  let sameCount = 0;

  try {
    for (let step = 0; step < MAX_STEPS; step++) {
      const modal = await getModal(page);
      if (!modal) return { status: "needs_review", reason: "modal fechou inesperadamente" };

      if (!resumeDone) resumeDone = await attachResume(modal);

      const result = await fillStep(page, modal, job);
      if (!result.ok) {
        return {
          status: "needs_answers",
          reason: `pergunta(s) sem resposta: ${result.unknown.map((f) => `"${f.question.slice(0, 50)}"`).join(", ")}`
        };
      }

      const submit = await visibleButton(modal, SUBMIT_RE);
      if (submit) return await reviewAndMaybeSubmit(page);

      const next = await visibleButton(modal, NEXT_RE);
      if (!next) return { status: "needs_review", reason: "não achei botão Avançar/Revisar" };

      const before = await progressSignature(modal);
      await next.click();
      await humanDelay(900, 1800);

      const errors = await visibleErrors(modal);
      const after = await progressSignature(modal);

      if (after === before) {
        sameCount++;
        if (errors.length && sameCount >= 2) {
          return { status: "needs_review", reason: `validação: ${errors.slice(0, 2).join(" / ")}` };
        }
        if (sameCount >= 3) return { status: "needs_review", reason: "formulário não avançou" };
      } else {
        sameCount = 0;
      }
      lastSig = after;
    }
    return { status: "needs_review", reason: `limite de ${MAX_STEPS} etapas atingido (${lastSig})` };
  } finally {
    await closeModal(page);
  }
}
