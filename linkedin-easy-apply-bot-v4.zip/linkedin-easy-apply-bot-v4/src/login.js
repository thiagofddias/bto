import { launchBrowser, newContext, isLoginUrl } from "./browser.js";
import { config } from "./config.js";
import { ask, canPrompt } from "./utils.js";

const browser = await launchBrowser();
const context = await newContext(browser, { useState: false });
const page = await context.newPage();

try {
  await page.goto("https://www.linkedin.com/login", { waitUntil: "domcontentloaded" });

  if (config.linkedinEmail && config.linkedinPassword) {
    await page.locator("#username").fill(config.linkedinEmail).catch(() => {});
    await page.locator("#password").fill(config.linkedinPassword).catch(() => {});
    await page.locator('button[type="submit"]').click().catch(() => {});
  }

  console.log("Faça o login e conclua qualquer verificação manualmente no navegador.");

  if (canPrompt()) {
    await ask("Pressione ENTER aqui quando estiver logado (vendo o feed)... ");
  } else {
    console.log("Aguardando até 5 minutos pelo login...");
    await page.waitForURL((u) => /linkedin\.com\/(feed|jobs|mynetwork|in\/)/.test(u.toString()), { timeout: 300_000 });
  }

  if (isLoginUrl(page.url())) {
    console.error("❌ Parece que o login não foi concluído (ainda está na página de login/verificação). Nada foi salvo.");
    process.exitCode = 1;
  } else {
    await context.storageState({ path: config.stateFile });
    console.log(`✅ Sessão salva em ${config.stateFile}. Agora rode: npm start`);
  }
} finally {
  await browser.close();
}
