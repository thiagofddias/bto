import { config } from "./config.js";
import { humanDelay } from "./utils.js";

const PAGE_SIZE = 25;

export function extractJobIdFromUrl(href = "") {
  if (!href) return "";
  const patterns = [
    /\/jobs\/view\/(\d+)/i,
    /\/jobs\/(\d+)(?:\/|\?|$)/i,
    /[?&]jobId=(\d+)/i,
    /[?&]job_id=(\d+)/i
  ];

  for (const pattern of patterns) {
    const match = href.match(pattern);
    if (match) return match[1];
  }

  return "";
}

/** Rola a lista de resultados (que é "virtualizada") coletando os cards pelo caminho. */
async function collectCards(page) {
  return page.evaluate(async () => {
    const found = {};
    const lines = (t) => [...new Set((t || "").split("\n").map((x) => x.trim()).filter(Boolean))];
    const undouble = (t) => {
      const w = t.split(" ");
      const h = w.length / 2;
      return w.length % 2 === 0 && w.slice(0, h).join(" ") === w.slice(h).join(" ") ? w.slice(0, h).join(" ") : t;
    };
    const extractJobId = (href = "") => {
      if (!href) return "";
      const patterns = [
        /\/jobs\/view\/(\d+)/i,
        /\/jobs\/(\d+)(?:\/|\?|$)/i,
        /[?&]jobId=(\d+)/i,
        /[?&]job_id=(\d+)/i
      ];
      for (const pattern of patterns) {
        const match = href.match(pattern);
        if (match) return match[1];
      }
      return "";
    };

    const collect = () => {
      const anchors = [...document.querySelectorAll('a[href*="/jobs/"]')].filter((a) => {
        const href = (a.getAttribute("href") || a.href || "");
        return /^\//.test(href) || /\/jobs\//i.test(href);
      });

      for (const a of anchors) {
        const href = a.getAttribute("href") || a.href || "";
        const id = extractJobId(href);
        if (!id) continue;
        const card = a.closest("li, [data-job-id], [data-occludable-job-id], .job-card-container, .base-card") || a.parentElement;
        if (!card) continue;
        if (card.closest(".jobs-search__job-details, .jobs-details, .scaffold-layout__detail")) continue;

        const pick = (sels) => {
          for (const s of sels) {
            const el = card.querySelector(s);
            if (el && el.innerText.trim()) return lines(el.innerText).join(" · ");
          }
          return "";
        };

        const cardLines = lines(card.innerText);
        const title = undouble((a.querySelector("strong, [aria-hidden='true']")?.innerText || lines(a.innerText)[0] || a.getAttribute("aria-label") || cardLines[0] || "").trim());
        const company =
          pick([".artdeco-entity-lockup__subtitle", ".job-card-container__primary-description", ".job-card-container__company-name", ".base-search-card__subtitle", ".job-card-container__company-name"]) ||
          cardLines.find((l) => l !== title) || "";
        const location =
          pick([".job-card-container__metadata-wrapper", ".artdeco-entity-lockup__caption", ".job-card-container__metadata-item", ".job-search-card__location", ".job-card-container__metadata"] ) ||
          cardLines.filter((l) => l !== title && l !== company)[0] || "";

        if (!title) continue;
        if (!found[id] || (!found[id].location && location)) {
          found[id] = {
            jobId: id,
            title,
            company,
            location,
            cardText: cardLines.join(" | "),
            url: href.startsWith("http") ? href : `https://www.linkedin.com${href}`
          };
        }
      }
    };

    const inDetail = (el) => el?.closest(".jobs-search__job-details, .jobs-details, .scaffold-layout__detail");
    const listAnchor = () => [...document.querySelectorAll('a[href*="/jobs/"]')].find((a) => !inDetail(a));

    for (let i = 0; i < 32 && !listAnchor(); i++) await new Promise((r) => setTimeout(r, 250));

    const scrollable = (el) => {
      const s = getComputedStyle(el);
      return /(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 20;
    };
    let scroller = listAnchor()?.parentElement;
    while (scroller && scroller !== document.body && !scrollable(scroller)) scroller = scroller.parentElement;
    if (!scroller || scroller === document.body) {
      scroller = [...document.querySelectorAll(".scaffold-layout__list, .scaffold-layout__list *, .jobs-search-results-list")]
        .find((el) => !inDetail(el) && scrollable(el));
    }
    const target = scroller || document.scrollingElement;

    collect();
    let stuck = 0;
    for (let i = 0; i < 40 && stuck < 3; i++) {
      const before = target.scrollTop;
      target.scrollBy(0, 350);
      await new Promise((r) => setTimeout(r, 300));
      collect();
      stuck = target.scrollTop === before ? stuck + 1 : 0;
    }
    return Object.values(found);
  });
}

export async function searchJobs(page, query) {
  const all = new Map();

  for (let p = 0; p < config.maxPagesPerQuery; p++) {
    const url = new URL("https://www.linkedin.com/jobs/search/");
    url.searchParams.set("keywords", query);
    url.searchParams.set("location", config.jobLocation);
    url.searchParams.set("f_AL", "true"); // só Candidatura simplificada
    if (config.datePosted) url.searchParams.set("f_TPR", config.datePosted);
    if (p > 0) url.searchParams.set("start", String(p * PAGE_SIZE));

    await page.goto(url.toString(), { waitUntil: "domcontentloaded" });
    const hasResults = await page
      .locator('li[data-occludable-job-id], [data-job-id], a[href*="/jobs/view/"]')
      .first()
      .waitFor({ timeout: 15000 })
      .then(() => true)
      .catch(() => false);
    if (!hasResults) break;

    await humanDelay();
    const cards = await collectCards(page);
    let added = 0;
    for (const card of cards) {
      if (!all.has(card.jobId)) {
        all.set(card.jobId, { ...card, query });
        added++;
      }
    }
    console.log(`   página ${p + 1}: ${cards.length} cards (${added} novos)`);
    if (added === 0 || cards.length < 5) break;
  }

  return [...all.values()];
}
