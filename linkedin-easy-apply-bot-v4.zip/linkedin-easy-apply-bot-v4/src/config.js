import "dotenv/config";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const dataDir = path.join(root, "data");

const csv = (value) =>
  (value || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

const num = (value, fallback) => {
  const n = Number(value);
  return Number.isFinite(n) && value !== "" && value != null ? n : fallback;
};

const bool = (value, fallback) => {
  if (value == null || value === "") return fallback;
  return !["false", "0", "no", "nao", "não"].includes(String(value).toLowerCase().trim());
};

const DEFAULT_FILTERS = {
  allowedLevels: ["trainee", "pleno", "senior"],
  excludedLevels: ["junior", "jr", "estagio", "estagiario", "estagiaria", "intern", "internship", "entry level", "aprendiz"],
  allowedLocations: ["remoto", "remote", "curitiba", "sao jose dos pinhais", "pinhais"],
  excludeUnknownLevel: true
};

function readFiltersFile() {
  try {
    return JSON.parse(fs.readFileSync(path.join(dataDir, "filters.json"), "utf8"));
  } catch {
    return {};
  }
}

const fileFilters = { ...DEFAULT_FILTERS, ...readFiltersFile() };

export const config = {
  root,
  dataDir,
  resumePath: path.join(root, "curriculo.pdf"),
  stateFile: path.join(root, "linkedin-state.json"),
  historyFile: path.join(dataDir, "history.json"),
  answersFile: path.join(dataDir, "answers.json"),
  unansweredFile: path.join(dataDir, "unanswered.txt"),
  skippedFile: path.join(dataDir, "skipped.json"),
  blacklistFile: path.join(dataDir, "blacklist.json"),

  linkedinEmail: process.env.LINKEDIN_EMAIL || "",
  linkedinPassword: process.env.LINKEDIN_PASSWORD || "",
  linkedinProfile: process.env.LINKEDIN_PROFILE || "",
  phoneNumber: process.env.PHONE_NUMBER || "",
  headless: bool(process.env.HEADLESS, false),
  debugModal: bool(process.env.DEBUG_MODAL, false),

  maxApplications: num(process.env.MAX_APPLICATIONS, 20),
  matchMinScore: num(process.env.MATCH_MIN_SCORE, 65),

  jobQueries: csv(process.env.JOB_QUERIES).length
    ? csv(process.env.JOB_QUERIES)
    : ["Software Engineer", "Backend Engineer", "Frontend Developer", "Full Stack Developer"],
  jobLocation: process.env.JOB_LOCATION || "Brasil",
  maxPagesPerQuery: num(process.env.MAX_PAGES_PER_QUERY, 3),
  datePosted: process.env.DATE_POSTED ?? "",

  reviewBeforeSubmit: bool(process.env.REVIEW_BEFORE_SUBMIT, true),
  interactiveAnswers: bool(process.env.INTERACTIVE_ANSWERS, true),
  uploadResume: (process.env.UPLOAD_RESUME || "auto").toLowerCase(),

  delayMinMs: num(process.env.DELAY_MIN_MS, 1200),
  delayMaxMs: num(process.env.DELAY_MAX_MS, 3000),

  filters: {
    allowedLevels: csv(process.env.ALLOWED_LEVELS).length ? csv(process.env.ALLOWED_LEVELS) : fileFilters.allowedLevels,
    excludedLevels: fileFilters.excludedLevels,
    allowedLocations: csv(process.env.ALLOWED_LOCATIONS).length
      ? csv(process.env.ALLOWED_LOCATIONS)
      : fileFilters.allowedLocations,
    excludeUnknownLevel: bool(process.env.EXCLUDE_UNKNOWN_LEVEL, fileFilters.excludeUnknownLevel)
  }
};

const defaults = {
  "answers.json": { version: 1, intents: {} },
  "blacklist.json": { companies: [], keywords: [] },
  "history.json": {},
  "skipped.json": [],
  "filters.json": DEFAULT_FILTERS
};

export function ensureDataFiles() {
  fs.mkdirSync(config.dataDir, { recursive: true });
  for (const [name, content] of Object.entries(defaults)) {
    const file = path.join(config.dataDir, name);
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(content, null, 2) + "\n", "utf8");
  }
  if (!fs.existsSync(config.unansweredFile)) {
    fs.writeFileSync(
      config.unansweredFile,
      "# Perguntas que o bot ainda não conseguiu identificar.\n# Cadastre a nova intenção em data/answers.json e rode novamente.\n",
      "utf8"
    );
  }
}
