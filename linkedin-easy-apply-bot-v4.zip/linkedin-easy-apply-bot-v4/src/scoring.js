import { hasTerm } from "./utils.js";

const positive = [
  "software engineer", "software developer", "desenvolvedor", "backend", "back end", "frontend", "front end",
  "full stack", "fullstack", "golang", "go developer", "desenvolvedor go", "typescript", "javascript",
  "node", "nodejs", "react", "next js", "python", "microservices", "microsservicos", "aws", "docker",
  "kubernetes", "rabbitmq", "postgres", "postgresql", "api", "rest", "graphql"
];

const negative = ["sales", "vendas", "customer support", "suporte tecnico", "designer", "qa manual", "help desk"];

export function scoreJob(job) {
  const title = job.title || "";
  const text = `${title} ${job.description || job.cardText || ""}`;
  let score = 50;

  for (const term of positive) {
    if (hasTerm(title, term)) score += 8;
    else if (hasTerm(text, term)) score += 4;
  }
  for (const term of negative) {
    if (hasTerm(title, term)) score -= 30;
    else if (hasTerm(text, term)) score -= 5;
  }

  return Math.max(0, Math.min(100, score));
}
