import { humanDelay } from "./utils.js";

const EASY_APPLY_RE = /easy apply|candidatura simplificada/i;

/** Botão "Candidatura simplificada" (ignora o "Candidatar-se" externo). */
export async function findEasyApplyButton(page) {
  const candidates = page.locator(
    'button.jobs-apply-button, button[aria-label], a[aria-label*="apply" i], a[aria-label*="candidatura" i], a[href*="/apply/"]'
  );
  const n = await candidates.count();
  for (let i = 0; i < n; i++) {
    const el = candidates.nth(i);
    if (!(await el.isVisible().catch(() => false))) continue;
    const label = `${(await el.getAttribute("aria-label").catch(() => "")) || ""} ${(await el.innerText().catch(() => "")) || ""}`;
    if (EASY_APPLY_RE.test(label) && !(await el.isDisabled().catch(() => false))) return el;
  }
  const byRole = page.getByRole("button", { name: EASY_APPLY_RE }).first();
  if (await byRole.isVisible().catch(() => false)) return byRole;
  return null;
}

/** Abre a vaga e extrai descrição, cabeçalho e critérios. */
export async function loadJobDetails(page, job) {
  await page.goto(job.url, { waitUntil: "domcontentloaded" });
  await page
    .locator('#job-details, .jobs-description__content, .jobs-description, [class*="jobs-description"]')
    .first()
    .waitFor({ timeout: 15000 })
    .catch(() => {});
  await humanDelay(800, 1600);

  // Expande "exibir mais" se existir
  const more = page.locator('button[aria-label*="see more" i], button[aria-label*="exibir mais" i], .jobs-description__footer-button').first();
  if (await more.isVisible().catch(() => false)) await more.click().catch(() => {});

  const info = await page.evaluate(() => {
    const first = (sels) => {
      for (const s of sels) {
        const el = document.querySelector(s);
        if (el && el.innerText.trim()) return el.innerText.trim();
      }
      return "";
    };
    const main = (document.querySelector("main") || document.body).innerText || "";
    const description = first(["#job-details", ".jobs-description__content", ".jobs-box__html-content", '[class*="jobs-description"]']);
    const topCard = first([
      ".job-details-jobs-unified-top-card__container--two-pane",
      ".jobs-unified-top-card",
      ".job-details-jobs-unified-top-card__primary-description-container",
      '[class*="unified-top-card"]'
    ]);
    const criteria = [
      ...document.querySelectorAll(
        ".description__job-criteria-item, .job-details-jobs-unified-top-card__job-insight, .job-details-preferences-and-skills, .job-details-fit-level-preferences button, .job-details-jobs-unified-top-card__job-insight-view-model-secondary"
      )
    ]
      .map((e) => e.innerText.trim())
      .filter(Boolean)
      .join(" | ");
    return {
      description: description || main.slice(0, 8000),
      topCard: topCard || main.slice(0, 1500),
      criteria
    };
  });

  const easyApply = await findEasyApplyButton(page);
  const header = `${info.topCard} ${info.criteria}`;
  const alreadyApplied =
    /\b(applied|candidatou-se|candidatura enviada|você se candidatou)\b/i.test(header) && !easyApply;

  return { ...job, ...info, hasEasyApply: Boolean(easyApply), alreadyApplied };
}
