import readline from "node:readline/promises";
import { config } from "./config.js";

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Pausa aleatória entre ações, para manter um ritmo humano. */
export function humanDelay(min = config.delayMinMs, max = config.delayMaxMs) {
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  return sleep(lo + Math.random() * (hi - lo));
}

export function normalize(value = "") {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** true se `term` aparece em `text` como palavra/frase inteira (sem casar "go" em "google"). */
export function hasTerm(text, term) {
  const t = normalize(term);
  if (!t) return false;
  return ` ${normalize(text)} `.includes(` ${t} `);
}

export function countTerm(text, term) {
  const t = normalize(term);
  if (!t) return 0;
  const hay = ` ${normalize(text)} `;
  let count = 0;
  let idx = hay.indexOf(` ${t} `);
  while (idx !== -1) {
    count++;
    idx = hay.indexOf(` ${t} `, idx + t.length + 1);
  }
  return count;
}

export function hasAnyTerm(text, terms = []) {
  return terms.find((term) => hasTerm(text, term)) || null;
}

export const canPrompt = () => Boolean(process.stdin.isTTY && process.stdout.isTTY);

export async function ask(question) {
  if (!canPrompt()) return null;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    return (await rl.question(question)).trim();
  } finally {
    rl.close();
  }
}
