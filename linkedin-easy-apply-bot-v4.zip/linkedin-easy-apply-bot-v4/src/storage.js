import fs from "node:fs";
import { config } from "./config.js";
import { normalize, hasTerm } from "./utils.js";

export { normalize };

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2) + "\n", "utf8");
  fs.renameSync(tmp, file);
}

function tokenSet(value) {
  return new Set(normalize(value).split(" ").filter((t) => t.length > 1));
}

function similarity(a, b) {
  const aa = tokenSet(a);
  const bb = tokenSet(b);
  if (!aa.size || !bb.size) return 0;
  let intersection = 0;
  for (const token of aa) if (bb.has(token)) intersection++;
  return intersection / Math.max(aa.size, bb.size);
}

export function readAnswers() {
  return readJson(config.answersFile, { version: 1, intents: {} });
}

/**
 * Descobre a intenção da pergunta. Frase-chave contida na pergunta vale 1;
 * senão usa similaridade de tokens. Keywords maiores vencem empates.
 */
export function detectIntent(question, answers = readAnswers()) {
  const q = normalize(question);
  if (!q) return null;
  let best = null;

  for (const [intent, entry] of Object.entries(answers.intents || {})) {
    if (entry.notIfMatches) {
      try {
        if (new RegExp(entry.notIfMatches, "i").test(q)) continue;
      } catch {}
    }

    for (const keyword of entry.keywords || []) {
      const score = hasTerm(q, keyword) ? 1 : similarity(q, keyword);
      const len = normalize(keyword).length;
      if (!best || score > best.score || (score === best.score && len > best.len)) {
        best = { intent, entry, score, keyword, len };
      }
    }
  }

  return best && best.score >= 0.72 ? best : null;
}

export function answerForIntent(match, context = {}) {
  if (!match) return null;
  const { entry } = match;

  if (entry.clt != null || entry.pj != null) {
    const text = normalize(context.jobText || "");
    const isPJ = /\bpj\b|pessoa juridica|prestador de servico|contractor|\bb2b\b|\bcnpj\b/.test(text);
    const isCLT = /\bclt\b|efetivo|regime celetista/.test(text);
    if (isPJ && !isCLT) return entry.pj ?? entry.default ?? null;
    if (isCLT && !isPJ) return entry.clt ?? entry.default ?? null;
    return entry.default ?? entry.clt ?? null;
  }

  return entry.answer ?? null;
}

export function appendUnanswered({ question, options = [], jobTitle = "", company = "", url = "", intentGuess = "", note = "" }) {
  const block = [
    "\n---",
    `Data: ${new Date().toISOString()}`,
    `Vaga: ${jobTitle}`,
    `Empresa: ${company}`,
    `URL: ${url}`,
    `Possível intenção: ${intentGuess || "não identificada"}`,
    `Pergunta: ${question}`,
    options.length ? `Opções: ${options.join(" | ")}` : "Opções: (campo livre)",
    note ? `Obs: ${note}` : null,
    "---"
  ]
    .filter((x) => x !== null)
    .join("\n");

  fs.appendFileSync(config.unansweredFile, block + "\n", "utf8");
}

export function learnAnswer(intent, answer, keywords = []) {
  const data = readAnswers();
  data.intents ||= {};

  if (!data.intents[intent]) {
    data.intents[intent] = { keywords, answer };
  } else {
    data.intents[intent].answer = answer;
    data.intents[intent].keywords = [...new Set([...(data.intents[intent].keywords || []), ...keywords])];
  }

  writeJson(config.answersFile, data);
}

export function intentIdFromQuestion(question) {
  const base = normalize(question).split(" ").slice(0, 7).join("_").slice(0, 60) || "pergunta";
  const existing = readAnswers().intents || {};
  let id = `learned_${base}`;
  let n = 2;
  while (existing[id]) id = `learned_${base}_${n++}`;
  return id;
}

// ---------- histórico de vagas ----------

export function readHistory() {
  return readJson(config.historyFile, {});
}

export function recordHistory(job, status, reason = "") {
  if (!job.jobId) return;
  const history = readHistory();
  history[job.jobId] = {
    status,
    reason,
    title: job.title,
    company: job.company,
    url: job.url,
    date: new Date().toISOString()
  };
  writeJson(config.historyFile, history);
}
