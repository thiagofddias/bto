import { launchBrowser, newContext, ensureLoggedIn } from "./browser.js";
import { config, ensureDataFiles } from "./config.js";
import { searchJobs } from "./search.js";
import { passesCardFilters, passesJobFilters } from "./filters.js";
import { isBlacklisted } from "./blacklist.js";
import { scoreJob } from "./scoring.js";
import { loadJobDetails } from "./job.js";
import { applyToJob } from "./apply.js";
import { readHistory, recordHistory } from "./storage.js";
import { humanDelay } from "./utils.js";
import fs from "node:fs";

// Status que não precisam ser reprocessados em execuções futuras
const FINAL_STATUSES = new Set(["submitted_manually", "already_applied", "not_easy_apply"]);

ensureDataFiles();

if (!fs.existsSync(config.stateFile)) {
  console.error("❌ Sessão não encontrada. Rode primeiro: npm run login");
  process.exit(1);
}
if (config.headless && config.reviewBeforeSubmit) {
  console.warn("⚠️  HEADLESS=true: você não verá o navegador para revisar. Os formulários serão só preenchidos e descartados.");
}

const browser = await launchBrowser();
const summary = [];
let interrupted = false;

process.on("SIGINT", () => {
  if (interrupted) process.exit(130);
  interrupted = true;
  console.log("\n⏹  Interrompendo após a vaga atual (Ctrl+C de novo para sair já)...");
});

try {
  const context = await newContext(browser);
  const page = await context.newPage();
  page.setDefaultTimeout(15000);

  if (!(await ensureLoggedIn(page))) {
    console.error("❌ Sessão expirada ou inválida. Rode novamente: npm run login");
    process.exitCode = 1;
  } else {
    // Renova a sessão salva
    await context.storageState({ path: config.stateFile }).catch(() => {});

    const history = readHistory();
    const found = new Map();

    for (const query of config.jobQueries) {
      if (interrupted) break;
      console.log(`\n🔎 Buscando: ${query}`);
      const jobs = await searchJobs(page, query).catch((err) => {
        console.log(`   erro na busca: ${err.message.split("\n")[0]}`);
        return [];
      });
      for (const job of jobs) if (!found.has(job.jobId)) found.set(job.jobId, job);
      await humanDelay();
    }

    const cards = [...found.values()].filter((job) => {
      if (FINAL_STATUSES.has(history[job.jobId]?.status)) return false;
      const f = passesCardFilters(job);
      if (!f.allowed) {
        console.log(`⛔ ${job.title} | ${job.company} — ${f.reason}`);
        return false;
      }
      const b = isBlacklisted(job);
      if (b.blocked) {
        console.log(`🚫 ${job.title} | ${job.company} — ${b.reason}`);
        return false;
      }
      return true;
    });

    // Cards com melhor score (pelo texto do card) primeiro
    cards.sort((a, b) => scoreJob(b) - scoreJob(a));
    console.log(`\n📋 ${found.size} vaga(s) encontradas, ${cards.length} passaram no pré-filtro.`);

    let attempts = 0;
    for (const card of cards) {
      if (interrupted || attempts >= config.maxApplications) break;

      let job;
      try {
        job = await loadJobDetails(page, card);
      } catch (err) {
        console.log(`⚠️  ${card.title} — erro ao abrir vaga: ${err.message.split("\n")[0]}`);
        continue;
      }
      job.score = scoreJob(job);

      const skip = (status, reason) => {
        console.log(`⏭  ${job.title} | ${job.company} — ${reason}`);
        recordHistory(job, status, reason);
      };

      if (job.alreadyApplied) { skip("already_applied", "você já se candidatou"); continue; }
      if (!job.hasEasyApply) { skip("not_easy_apply", "sem Candidatura simplificada"); continue; }

      const filter = passesJobFilters(job);
      if (!filter.allowed) { skip("filtered", filter.reason); continue; }

      const bl = isBlacklisted(job);
      if (bl.blocked) { skip("blacklisted", bl.reason); continue; }

      if (job.score < config.matchMinScore) { skip("low_score", `score ${job.score} < ${config.matchMinScore}`); continue; }

      attempts++;
      console.log(`\n➡️  [${attempts}/${config.maxApplications}] ${job.title} | ${job.company} | ${job.location} | ${filter.level} | score ${job.score}`);

      let result;
      try {
        result = await applyToJob(page, job);
      } catch (err) {
        result = { status: "error", reason: err.message.split("\n")[0] };
      }

      console.log(`   → ${result.status}: ${result.reason}`);
      recordHistory(job, result.status, result.reason);
      summary.push({
        vaga: job.title.slice(0, 40),
        empresa: job.company.slice(0, 25),
        score: job.score,
        status: result.status,
        motivo: result.reason.slice(0, 60)
      });

      await humanDelay(config.delayMinMs * 2, config.delayMaxMs * 2);
    }
  }
} finally {
  if (summary.length) console.table(summary);
  else console.log("\nNenhum formulário foi aberto nesta execução.");
  await browser.close().catch(() => {});
}
